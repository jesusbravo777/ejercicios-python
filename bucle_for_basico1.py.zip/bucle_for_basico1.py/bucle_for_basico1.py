
# Ejercicio 1: Básico
# Mostrar los números del 0 al 100

for numero in range(101):
    print(numero)


# Ejercicio 2: Múltiplos de 2
# Mostrar los números pares del 2 al 500

for numero in range(2, 501, 2):
    print(numero)


# Ejercicio 3: Contando Vanilla Ice
# Mostrar números del 1 al 100
# Si es múltiplo de 10, mostrar "baby"
# Si es múltiplo de 5, mostrar "ice ice"

for numero in range(1, 101):
    if numero % 10 == 0:
        print("baby")
    elif numero % 5 == 0:
        print("ice ice")
    else:
        print(numero)


# Ejercicio 4: Número gigante
# Sumar todos los números pares del 0 al 500000

suma = 0

for numero in range(0, 500001, 2):
    suma = suma + numero

print("La suma total es:", suma)


# Ejercicio 5: Regresando de 3 en 3
# Contar desde 2024 hasta llegar al último positivo

for numero in range(2024, 0, -3):
    print(numero)


# Ejercicio 6: Contador dinámico
# Mostrar los múltiplos de una variable

numInicial = 3
numFinal = 10
multiplo = 2

for numero in range(numInicial, numFinal + 1):
    if numero % multiplo == 0:
        print(numero)
